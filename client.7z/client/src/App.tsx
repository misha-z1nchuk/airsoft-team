import React, {useContext, useEffect, useState} from 'react';
import LoginForm from "./components/LoginForm";
import {Context} from "./index";
import {observer} from "mobx-react-lite";

import { store as ntf} from 'react-notifications-component';
import ReactNotification from 'react-notifications-component'
import 'react-notifications/lib/notifications.css';
import EventListening from "./components/EventListening";
import {BrowserRouter, Route, Routes} from "react-router-dom";
import {publicRoutes} from "./routes";
import AppRouter from "./components/AppRouter";




function App() {
    const {store} = useContext(Context);

    // useEffect(() => {
    //     if(localStorage.getItem('token')){
    //         store.checkAuth()
    //     }
    // }, [])
    //
    // if (store.isLoading){
    //     return <div>Loading...</div>
    // }
    //
    // if (!store.isAuth){
    //     return (
    //         <LoginForm/>
    //     )
    // }
    //
    // function doSmth() {
    //     ntf.addNotification({
    //         title: "Wonderful!",
    //         message: "teodosii@react-notifications-component",
    //         type: "danger",
    //         insert: "bottom",
    //         container: "bottom-right",
    //         dismiss: {
    //             duration: 5000,
    //             onScreen: true
    //         }
    //     });
    // }

    return (
    <div>
        <AppRouter/>


        {/*<button onClick={() => doSmth()}>Log out</button>*/}
        {/*<h1>{store.isAuth ? `User authorized ${store.user.email}` : `Authorize pls`}</h1>*/}
        {/*<h1>{store.user.isActivated ? 'Account activated' : "Activate your account pls"}</h1>*/}
        {/*<button onClick={() => store.logout()}>Log out</button>*/}
        {/*<EventListening/>*/}
        {/*<ReactNotification/>*/}
    </div>
)}

export default observer(App);
