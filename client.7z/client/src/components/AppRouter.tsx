import React from 'react';
import{
    BrowserRouter as Router,
    Route,
    Link,
    Routes
} from "react-router-dom";
import {authRoutes, publicRoutes} from "../routes";
import {SERVICE_ROUTE} from "../utils/consts";
import Auth from "../pages/Auth";
import NotFound from "../pages/NotFound";

const AppRouter = () => {
    const isAuth: boolean = false;
    return (

        <Routes>
            <Route path="*" element={<NotFound/>}/>

            {isAuth && authRoutes.map(({path, Component}) =>
                <Route key={path} path={path} element={<Component/>}/>
            )}
            {publicRoutes.map(({path, Component}) =>
                <Route key={path} path={path} element={<Component/>}/>
            )}
        </Routes>
    );
};


export default AppRouter;